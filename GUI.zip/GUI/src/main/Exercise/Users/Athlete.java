package Users;

import PriceList.PriceList;

import java.io.Serializable;

public class Athlete extends User implements PriceList
{
    private boolean professional;
    private int experienceLevel;
    private static int athlUniqueCode;

    public Athlete(String firstName, String lastName, String gender, String contactInformation, String dateOfBirth, boolean professional, int experienceLevel)
    {
        super(firstName, lastName, gender, contactInformation, dateOfBirth);

        this.professional = professional;
        this.experienceLevel = experienceLevel;
    }

    @Override
    public double calculateTotalPrice()
    {
        return 0;
    }

    public int getExperienceLevel()
    {
        return experienceLevel;
    }

    public void setExperienceLevel(int experienceLevel)
    {
        this.experienceLevel = experienceLevel;
    }

    public boolean isProfessional()
    {
        return professional;
    }

    public void setProfessional(boolean professional)
    {
        this.professional = professional;
    }

}
