package Users;
import PriceList.PriceList;
public abstract class User
{
    private String firstName;
    private String lastName;
    private String gender;
    private String contactInformation;
    private String dateOfBirth;
    private static int uniqueCode = 0;

    public User(String firstName, String lastName, String gender, String contactInformation, String dateOfBirth)
    {
        User.uniqueCode++;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.contactInformation = contactInformation;
        this.dateOfBirth = dateOfBirth;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getGender()
    {
        return gender;
    }

    public void setGender(String gender)
    {
        this.gender = gender;
    }

    public String getContactInformation()
    {
        return contactInformation;
    }

    public void setContactInformation(String contactInformation)
    {
        this.contactInformation = contactInformation;
    }

    public int getUniqueCode()
    {
        return User.uniqueCode;
    }

    public String getDateOfBirth()
    {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth)
    {
        this.dateOfBirth = dateOfBirth;
    }


}
