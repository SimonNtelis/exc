package Users;

import PriceList.PriceList;

public class Coach extends User  implements PriceList
{
    private String sport;
    private String degrees;

    public Coach(String firstName, String lastName, String gender, String contactInformation, String dateOfBirth, String sport, String degrees)
    {
        super(firstName, lastName, gender, contactInformation, dateOfBirth);

        this.sport = sport;
        this.degrees = degrees;
    }

    @Override
    public double calculateTotalPrice()
    {
        return 0;
    }

    public String getSport()
    {
        return sport;
    }

    public void setSport(String sport)
    {
        this.sport = sport;
    }

    public String getDegrees()
    {
        return degrees;
    }

    public void setDegrees(String degrees)
    {
        this.degrees = degrees;
    }



}
