package PriceList;

public interface PriceList
{
    public double calculateTotalPrice();
}
